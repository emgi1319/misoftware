#!/bin/bash
echo "Iniciando Aplicacion de Productividad..."
echo ""
echo "Por favor espere mientras se inicia el servidor..."
echo ""

# Navegar al directorio del script
cd "$(dirname "$0")"

# Iniciar la aplicación
npm run dev

# Esperar a que el usuario presione una tecla antes de cerrar
read -p "Presione Enter para salir..."

