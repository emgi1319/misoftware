"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Database, Save, Download, User } from "lucide-react"

export default function ConfiguracionPage() {
  const [autoSave, setAutoSave] = useState(true)
  const [darkMode, setDarkMode] = useState(false)
  const [dbPath, setDbPath] = useState("C:/Users/Usuario/Documents/ProductividadApp/data")

  return (
    <div className="container mx-auto py-10">
      <h1 className="mb-6 text-3xl font-bold">Configuración</h1>

      <Tabs defaultValue="general">
        <TabsList className="mb-6">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="database">Base de Datos</TabsTrigger>
          <TabsTrigger value="backup">Respaldo</TabsTrigger>
          <TabsTrigger value="account">Cuenta</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>Configuración General</CardTitle>
              <CardDescription>Personaliza la apariencia y comportamiento de la aplicación</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-save">Guardar automáticamente</Label>
                  <p className="text-sm text-muted-foreground">Guarda automáticamente los cambios en las tareas</p>
                </div>
                <Switch id="auto-save" checked={autoSave} onCheckedChange={setAutoSave} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="dark-mode">Modo oscuro</Label>
                  <p className="text-sm text-muted-foreground">Cambia la apariencia de la aplicación a modo oscuro</p>
                </div>
                <Switch id="dark-mode" checked={darkMode} onCheckedChange={setDarkMode} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="language">Idioma</Label>
                <Select defaultValue="es">
                  <SelectTrigger id="language">
                    <SelectValue placeholder="Selecciona un idioma" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="es">Español</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="pt">Português</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="database">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Base de Datos</CardTitle>
              <CardDescription>Configura la ubicación y opciones de la base de datos local</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="db-path">Ruta de la base de datos</Label>
                <div className="flex gap-2">
                  <Input id="db-path" value={dbPath} onChange={(e) => setDbPath(e.target.value)} />
                  <Button variant="outline">Examinar...</Button>
                </div>
                <p className="text-sm text-muted-foreground">Ubicación donde se guardarán los datos de la aplicación</p>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="db-encryption">Cifrar base de datos</Label>
                  <p className="text-sm text-muted-foreground">Protege tus datos con cifrado</p>
                </div>
                <Switch id="db-encryption" />
              </div>

              <Button className="flex items-center gap-1">
                <Database className="h-4 w-4" />
                Inicializar Base de Datos
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backup">
          <Card>
            <CardHeader>
              <CardTitle>Respaldo y Recuperación</CardTitle>
              <CardDescription>Configura opciones de respaldo y recuperación de datos</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-backup">Respaldo automático</Label>
                  <p className="text-sm text-muted-foreground">Crea respaldos automáticos de tus datos</p>
                </div>
                <Switch id="auto-backup" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="backup-frequency">Frecuencia de respaldo</Label>
                <Select defaultValue="weekly">
                  <SelectTrigger id="backup-frequency">
                    <SelectValue placeholder="Selecciona la frecuencia" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Diario</SelectItem>
                    <SelectItem value="weekly">Semanal</SelectItem>
                    <SelectItem value="monthly">Mensual</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="backup-location">Ubicación de respaldos</Label>
                <div className="flex gap-2">
                  <Input id="backup-location" defaultValue="C:/Users/Usuario/Documents/ProductividadApp/backups" />
                  <Button variant="outline">Examinar...</Button>
                </div>
              </div>

              <div className="flex gap-2">
                <Button className="flex items-center gap-1">
                  <Save className="h-4 w-4" />
                  Crear Respaldo Ahora
                </Button>
                <Button variant="outline" className="flex items-center gap-1">
                  <Download className="h-4 w-4" />
                  Restaurar Respaldo
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Cuenta</CardTitle>
              <CardDescription>Gestiona tu información de usuario y preferencias</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="username">Nombre de usuario</Label>
                <Input id="username" defaultValue="Usuario" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Correo electrónico</Label>
                <Input id="email" type="email" defaultValue="usuario@ejemplo.com" />
              </div>

              <Button className="flex items-center gap-1">
                <User className="h-4 w-4" />
                Actualizar Perfil
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

