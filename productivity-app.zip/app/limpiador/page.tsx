"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Copy, Check } from "lucide-react"

export default function LimpiadorPage() {
  const [inputText, setInputText] = useState("")
  const [cleanedText, setCleanedText] = useState("")
  const [copied, setCopied] = useState(false)
  const textAreaRef = useRef<HTMLDivElement>(null)

  const cleanText = () => {
    if (!inputText.trim()) return

    // Eliminar saltos de línea múltiples
    let text = inputText.replace(/\n+/g, " ")

    // Eliminar espacios múltiples
    text = text.replace(/\s+/g, " ")

    // Eliminar espacios antes de puntuación
    text = text.replace(/\s+([.,;:!?])/g, "$1")

    // Asegurar un espacio después de la puntuación
    text = text.replace(/([.,;:!?])([^\s])/g, "$1 $2")

    // Eliminar espacios al inicio y final
    text = text.trim()

    setCleanedText(text)
  }

  const copyToClipboard = () => {
    if (cleanedText) {
      navigator.clipboard.writeText(cleanedText)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="container mx-auto max-w-4xl">
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Limpiador de Texto</CardTitle>
          <CardDescription>Elimina saltos de línea y formatos innecesarios de tu texto</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Textarea
              placeholder="Pega aquí el texto que deseas limpiar..."
              className="min-h-[200px]"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
            />
          </div>

          <Button onClick={cleanText} className="w-full">
            Limpiar Texto
          </Button>

          {cleanedText && (
            <div className="mt-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-medium">Texto limpio:</h3>
                <Button variant="outline" size="sm" onClick={copyToClipboard} className="flex items-center gap-1">
                  {copied ? (
                    <>
                      <Check className="h-4 w-4" />
                      Copiado
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" />
                      Copiar
                    </>
                  )}
                </Button>
              </div>
              <div className="rounded-md border p-4 bg-muted/30" ref={textAreaRef}>
                {cleanedText}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

