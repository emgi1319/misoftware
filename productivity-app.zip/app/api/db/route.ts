import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"

// Ruta base para almacenar los datos
const DATA_DIR = path.join(process.cwd(), "data")

// Asegurarse de que el directorio existe
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true })
}

// Ruta del archivo de tareas
const TASKS_FILE = path.join(DATA_DIR, "tasks.json")

// Guardar tareas en el archivo
export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Guardar los datos en el archivo
    fs.writeFileSync(TASKS_FILE, JSON.stringify(data, null, 2))

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error al guardar tareas:", error)
    return NextResponse.json({ error: "Error al guardar tareas" }, { status: 500 })
  }
}

// Obtener tareas desde el archivo
export async function GET() {
  try {
    // Verificar si el archivo existe
    if (!fs.existsSync(TASKS_FILE)) {
      return NextResponse.json({ tasks: [] })
    }

    // Leer el archivo
    const data = fs.readFileSync(TASKS_FILE, "utf-8")
    const tasks = JSON.parse(data)

    return NextResponse.json({ tasks })
  } catch (error) {
    console.error("Error al leer tareas:", error)
    return NextResponse.json({ error: "Error al leer tareas" }, { status: 500 })
  }
}

