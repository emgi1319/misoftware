"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Copy, Check } from "lucide-react"

export default function CorrectorPage() {
  const [inputText, setInputText] = useState("")
  const [correctedText, setCorrectedText] = useState("")
  const [copied, setCopied] = useState(false)
  const textAreaRef = useRef<HTMLDivElement>(null)

  // Función mejorada para corregir ortografía
  const correctSpelling = () => {
    if (!inputText.trim()) return

    // Correcciones comunes en español
    const text = inputText
      // Palabras mal escritas
      .replace(/\baver\b/g, "a ver")
      .replace(/\bhaci\b/g, "así")
      .replace(/\bhalla\b/g, "haya")
      .replace(/\bhaiga\b/g, "haya")
      .replace(/\bhací\b/g, "así")
      .replace(/\bvalla\b/g, "vaya")
      .replace(/\bllendo\b/g, "yendo")
      .replace(/\bquisistes\b/g, "quisiste")
      .replace(/\bdijistes\b/g, "dijiste")
      .replace(/\bvinistes\b/g, "viniste")
      .replace(/\bfuistes\b/g, "fuiste")
      .replace(/\bnadien\b/g, "nadie")
      .replace(/\bsetiembre\b/g, "septiembre")

      // Acentos comunes
      .replace(/\bque\b/g, "qué")
      .replace(/\bcomo\b/g, "cómo")
      .replace(/\bcuando\b/g, "cuándo")
      .replace(/\bdonde\b/g, "dónde")
      .replace(/\bquien\b/g, "quién")
      .replace(/\bcual\b/g, "cuál")
      .replace(/\bcuanto\b/g, "cuánto")

      // Palabras con acento
      .replace(/\bultimo\b/g, "último")
      .replace(/\bultima\b/g, "última")
      .replace(/\bpracticamente\b/g, "prácticamente")
      .replace(/\bfacil\b/g, "fácil")
      .replace(/\bdificil\b/g, "difícil")
      .replace(/\brapido\b/g, "rápido")
      .replace(/\brapida\b/g, "rápida")
      .replace(/\bpublico\b/g, "público")
      .replace(/\bmedico\b/g, "médico")
      .replace(/\bpolitico\b/g, "político")
      .replace(/\beconomico\b/g, "económico")
      .replace(/\bpagina\b/g, "página")
      .replace(/\btelefono\b/g, "teléfono")
      .replace(/\bnumero\b/g, "número")
      .replace(/\bmusica\b/g, "música")

      // Plurales con acento
      .replace(/\bexamenes\b/g, "exámenes")
      .replace(/\bresumenes\b/g, "resúmenes")
      .replace(/\bvolumenes\b/g, "volúmenes")
      .replace(/\bimágenes\b/g, "imágenes")

      // Verbos con acento
      .replace(/\besto\b/g, "estó")
      .replace(/\besta\b/g, "está")
      .replace(/\bestan\b/g, "están")
      .replace(/\bestabamos\b/g, "estábamos")
      .replace(/\bestaran\b/g, "estarán")
      .replace(/\bhabia\b/g, "había")
      .replace(/\bhabian\b/g, "habían")
      .replace(/\bhabra\b/g, "habrá")
      .replace(/\bhabran\b/g, "habrán")
      .replace(/\bpodria\b/g, "podría")
      .replace(/\bpodrian\b/g, "podrían")
      .replace(/\btendria\b/g, "tendría")
      .replace(/\btendrian\b/g, "tendrían")

      // Signos de puntuación
      .replace(/([.!?])([A-Za-zÁÉÍÓÚáéíóúÑñ])/g, "$1 $2")
      .replace(/,([^ ])/g, ", $1")

    setCorrectedText(text)
  }

  const copyToClipboard = () => {
    if (correctedText) {
      navigator.clipboard.writeText(correctedText)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="container mx-auto max-w-4xl">
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Corrector Ortográfico</CardTitle>
          <CardDescription>
            Pega tu texto y haz clic en "Corregir" para obtener una versión sin faltas de ortografía
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Textarea
              placeholder="Pega aquí el texto que deseas corregir..."
              className="min-h-[200px]"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
            />
          </div>

          <Button onClick={correctSpelling} className="w-full">
            Corregir
          </Button>

          {correctedText && (
            <div className="mt-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-medium">Texto corregido:</h3>
                <Button variant="outline" size="sm" onClick={copyToClipboard} className="flex items-center gap-1">
                  {copied ? (
                    <>
                      <Check className="h-4 w-4" />
                      Copiado
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" />
                      Copiar
                    </>
                  )}
                </Button>
              </div>
              <div className="rounded-md border p-4 bg-muted/30" ref={textAreaRef}>
                {correctedText}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

