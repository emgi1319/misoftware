"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  PlusCircle,
  Calendar,
  Filter,
  CheckCircle2,
  Clock,
  AlertTriangle,
  AlertCircle,
  Edit,
  Trash2,
  Image,
  Save,
} from "lucide-react"
import FileSaver from "file-saver"

// Tipo para las tareas
type Priority = "baja" | "media" | "alta"
type Status = "pendiente" | "completada"

interface Task {
  id: string
  title: string
  description: string
  priority: Priority
  status: Status
  createdAt: Date
  imageUrl?: string
}

// Función para obtener el color según la prioridad
const getPriorityColor = (priority: Priority) => {
  switch (priority) {
    case "alta":
      return "bg-red-100 text-red-800 border-red-200"
    case "media":
      return "bg-orange-100 text-orange-800 border-orange-200"
    case "baja":
      return "bg-green-100 text-green-800 border-green-200"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

// Función para obtener el icono según la prioridad
const PriorityIcon = ({ priority }: { priority: Priority }) => {
  switch (priority) {
    case "alta":
      return <AlertCircle className="h-4 w-4 text-red-600" />
    case "media":
      return <AlertTriangle className="h-4 w-4 text-orange-600" />
    case "baja":
      return <Clock className="h-4 w-4 text-green-600" />
    default:
      return null
  }
}

export default function TareasPage() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [taskForm, setTaskForm] = useState<Omit<Task, "id" | "createdAt" | "status">>({
    title: "",
    description: "",
    priority: "media",
    imageUrl: "",
  })
  const [filterPriority, setFilterPriority] = useState<Priority | "todas">("todas")
  const [filterMonth, setFilterMonth] = useState<string>("todos")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null)
  const [selectedImage, setSelectedImage] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [lastSaved, setLastSaved] = useState<Date | null>(null)

  // Cargar tareas del localStorage al iniciar
  useEffect(() => {
    const savedTasks = localStorage.getItem("tasks")
    if (savedTasks) {
      try {
        const parsedTasks = JSON.parse(savedTasks).map((task: any) => ({
          ...task,
          createdAt: new Date(task.createdAt),
        }))
        setTasks(parsedTasks)
      } catch (error) {
        console.error("Error parsing tasks:", error)
      }
    }
  }, [])

  // Guardar tareas en localStorage cuando cambien
  useEffect(() => {
    if (tasks.length > 0) {
      localStorage.setItem("tasks", JSON.stringify(tasks))
      setLastSaved(new Date())
    }
  }, [tasks])

  // Configurar guardado automático cada 15 segundos
  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      if (tasks.length > 0) {
        localStorage.setItem("tasks", JSON.stringify(tasks))
        setLastSaved(new Date())
        console.log("Guardado automático de tareas ejecutado")
      }
    }, 15000) // 15 segundos

    return () => clearInterval(autoSaveInterval)
  }, [tasks])

  // Exportar tareas a un archivo JSON
  const exportTasks = () => {
    const tasksJson = JSON.stringify(tasks, null, 2)
    const blob = new Blob([tasksJson], { type: "application/json" })
    FileSaver.saveAs(blob, "mis-tareas.json")
  }

  // Importar tareas desde un archivo JSON
  const importTasks = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const importedTasks = JSON.parse(e.target?.result as string).map((task: any) => ({
            ...task,
            createdAt: new Date(task.createdAt),
          }))
          setTasks(importedTasks)
        } catch (error) {
          console.error("Error importing tasks:", error)
          alert("Error al importar tareas. Asegúrate de que el archivo tenga el formato correcto.")
        }
      }
      reader.readAsText(file)
    }
  }

  // Resetear el formulario
  const resetForm = () => {
    setTaskForm({
      title: "",
      description: "",
      priority: "media",
      imageUrl: "",
    })
    setSelectedImage(null)
    setEditingTaskId(null)
  }

  // Abrir el diálogo para editar una tarea
  const openEditDialog = (task: Task) => {
    setTaskForm({
      title: task.title,
      description: task.description,
      priority: task.priority,
      imageUrl: task.imageUrl || "",
    })
    setEditingTaskId(task.id)
    setIsDialogOpen(true)
  }

  // Manejar la selección de imagen
  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setSelectedImage(file)

      // Convertir la imagen a una URL de datos
      const reader = new FileReader()
      reader.onload = (e) => {
        setTaskForm({
          ...taskForm,
          imageUrl: e.target?.result as string,
        })
      }
      reader.readAsDataURL(file)
    }
  }

  // Agregar o actualizar una tarea
  const saveTask = () => {
    if (taskForm.title.trim() === "") return

    if (editingTaskId) {
      // Actualizar tarea existente
      setTasks(
        tasks.map((task) =>
          task.id === editingTaskId
            ? {
                ...task,
                title: taskForm.title,
                description: taskForm.description,
                priority: taskForm.priority,
                imageUrl: taskForm.imageUrl,
              }
            : task,
        ),
      )
    } else {
      // Agregar nueva tarea
      const task: Task = {
        id: Date.now().toString(),
        ...taskForm,
        status: "pendiente",
        createdAt: new Date(),
      }
      setTasks([...tasks, task])
    }

    resetForm()
    setIsDialogOpen(false)
  }

  // Cambiar el estado de una tarea
  const toggleTaskStatus = (id: string) => {
    setTasks(
      tasks.map((task) =>
        task.id === id ? { ...task, status: task.status === "pendiente" ? "completada" : "pendiente" } : task,
      ),
    )
  }

  // Eliminar una tarea
  const deleteTask = (id: string) => {
    if (confirm("¿Estás seguro de que deseas eliminar esta tarea?")) {
      setTasks(tasks.filter((task) => task.id !== id))
    }
  }

  // Filtrar tareas según los criterios seleccionados
  const filteredTasks = tasks.filter((task) => {
    // Filtrar por prioridad
    if (filterPriority !== "todas" && task.priority !== filterPriority) {
      return false
    }

    // Filtrar por mes
    if (filterMonth !== "todos") {
      const taskMonth = task.createdAt.getMonth().toString()
      if (taskMonth !== filterMonth) {
        return false
      }
    }

    return true
  })

  // Separar tareas por estado
  const pendingTasks = filteredTasks.filter((task) => task.status === "pendiente")
  const completedTasks = filteredTasks.filter((task) => task.status === "completada")

  // Generar opciones de meses para el filtro
  const months = [
    { value: "0", label: "Enero" },
    { value: "1", label: "Febrero" },
    { value: "2", label: "Marzo" },
    { value: "3", label: "Abril" },
    { value: "4", label: "Mayo" },
    { value: "5", label: "Junio" },
    { value: "6", label: "Julio" },
    { value: "7", label: "Agosto" },
    { value: "8", label: "Septiembre" },
    { value: "9", label: "Octubre" },
    { value: "10", label: "Noviembre" },
    { value: "11", label: "Diciembre" },
  ]

  return (
    <div className="container mx-auto max-w-7xl">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Gestor de Tareas</h1>
          {lastSaved && (
            <p className="text-sm text-muted-foreground mt-1">Último guardado: {lastSaved.toLocaleTimeString()}</p>
          )}
        </div>

        <div className="flex gap-2">
          <Button variant="outline" onClick={exportTasks}>
            Exportar Tareas
          </Button>
          <Button variant="outline" onClick={() => document.getElementById("import-tasks")?.click()}>
            Importar Tareas
          </Button>
          <input id="import-tasks" type="file" accept=".json" className="hidden" onChange={importTasks} />

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-1">
                <PlusCircle className="h-4 w-4" />
                Nueva Tarea
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editingTaskId ? "Editar Tarea" : "Agregar Nueva Tarea"}</DialogTitle>
                <DialogDescription>
                  Completa los detalles de la tarea y haz clic en guardar cuando termines.
                </DialogDescription>
              </DialogHeader>

              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="title">Título</Label>
                  <Input
                    id="title"
                    placeholder="Título de la tarea"
                    value={taskForm.title}
                    onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })}
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="description">Descripción</Label>
                  <Textarea
                    id="description"
                    placeholder="Descripción detallada de la tarea"
                    value={taskForm.description}
                    onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="priority">Prioridad</Label>
                  <Select
                    value={taskForm.priority}
                    onValueChange={(value: Priority) => setTaskForm({ ...taskForm, priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona la prioridad" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="baja">Baja</SelectItem>
                      <SelectItem value="media">Media</SelectItem>
                      <SelectItem value="alta">Alta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="image">Imagen</Label>
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center gap-1"
                    >
                      <Image className="h-4 w-4" />
                      {selectedImage ? "Cambiar imagen" : "Subir imagen"}
                    </Button>
                    {taskForm.imageUrl && <span className="text-sm text-muted-foreground">Imagen seleccionada</span>}
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImageSelect}
                  />
                  {taskForm.imageUrl && (
                    <div className="mt-2 rounded-md border p-2">
                      <img
                        src={taskForm.imageUrl || "/placeholder.svg"}
                        alt="Vista previa"
                        className="max-h-40 rounded-md object-contain"
                      />
                    </div>
                  )}
                </div>
              </div>

              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => {
                    resetForm()
                    setIsDialogOpen(false)
                  }}
                >
                  Cancelar
                </Button>
                <Button onClick={saveTask}>
                  <Save className="mr-1 h-4 w-4" />
                  {editingTaskId ? "Actualizar" : "Guardar"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filtros */}
      <div className="mb-6 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4" />
          <span className="text-sm font-medium">Filtrar por:</span>
        </div>

        <Select value={filterPriority} onValueChange={(value: Priority | "todas") => setFilterPriority(value)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Prioridad" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todas">Todas las prioridades</SelectItem>
            <SelectItem value="alta">Alta</SelectItem>
            <SelectItem value="media">Media</SelectItem>
            <SelectItem value="baja">Baja</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterMonth} onValueChange={(value) => setFilterMonth(value)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Mes" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos los meses</SelectItem>
            {months.map((month) => (
              <SelectItem key={month.value} value={month.value}>
                {month.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Tablero de tareas */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Columna de tareas pendientes */}
        <div>
          <h2 className="mb-4 flex items-center gap-2 text-xl font-semibold">
            <AlertCircle className="h-5 w-5 text-red-500" />
            Tareas Pendientes ({pendingTasks.length})
          </h2>

          <div className="space-y-4">
            {pendingTasks.length === 0 ? (
              <Card>
                <CardContent className="flex items-center justify-center p-6 text-muted-foreground">
                  No hay tareas pendientes
                </CardContent>
              </Card>
            ) : (
              pendingTasks.map((task) => (
                <Card key={task.id} className="overflow-hidden shadow-sm">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{task.title}</CardTitle>
                      <div
                        className={`flex items-center gap-1 rounded-full border px-2 py-1 text-xs font-medium ${getPriorityColor(
                          task.priority,
                        )}`}
                      >
                        <PriorityIcon priority={task.priority} />
                        {task.priority === "alta" ? "Urgente" : task.priority === "media" ? "Intermedio" : "Bajo"}
                      </div>
                    </div>
                    <CardDescription className="flex items-center gap-1 text-xs">
                      <Calendar className="h-3 w-3" />
                      {task.createdAt.toLocaleDateString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">{task.description}</p>
                    {task.imageUrl && (
                      <div className="mt-2">
                        <img
                          src={task.imageUrl || "/placeholder.svg"}
                          alt={task.title}
                          className="max-h-40 rounded-md object-contain"
                        />
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => openEditDialog(task)}>
                        <Edit className="mr-1 h-4 w-4" />
                        Editar
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => deleteTask(task.id)}>
                        <Trash2 className="mr-1 h-4 w-4" />
                        Eliminar
                      </Button>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => toggleTaskStatus(task.id)}>
                      <CheckCircle2 className="mr-1 h-4 w-4" />
                      Completar
                    </Button>
                  </CardFooter>
                </Card>
              ))
            )}
          </div>
        </div>

        {/* Columna de tareas completadas */}
        <div>
          <h2 className="mb-4 flex items-center gap-2 text-xl font-semibold">
            <CheckCircle2 className="h-5 w-5 text-green-500" />
            Tareas Completadas ({completedTasks.length})
          </h2>

          <div className="space-y-4">
            {completedTasks.length === 0 ? (
              <Card>
                <CardContent className="flex items-center justify-center p-6 text-muted-foreground">
                  No hay tareas completadas
                </CardContent>
              </Card>
            ) : (
              completedTasks.map((task) => (
                <Card key={task.id} className="overflow-hidden bg-green-50 shadow-sm">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg line-through">{task.title}</CardTitle>
                      <div
                        className={`flex items-center gap-1 rounded-full border px-2 py-1 text-xs font-medium ${getPriorityColor(
                          task.priority,
                        )}`}
                      >
                        <PriorityIcon priority={task.priority} />
                        {task.priority === "alta" ? "Urgente" : task.priority === "media" ? "Intermedio" : "Bajo"}
                      </div>
                    </div>
                    <CardDescription className="flex items-center gap-1 text-xs">
                      <Calendar className="h-3 w-3" />
                      {task.createdAt.toLocaleDateString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">{task.description}</p>
                    {task.imageUrl && (
                      <div className="mt-2">
                        <img
                          src={task.imageUrl || "/placeholder.svg"}
                          alt={task.title}
                          className="max-h-40 rounded-md object-contain"
                        />
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm" onClick={() => deleteTask(task.id)}>
                      <Trash2 className="mr-1 h-4 w-4" />
                      Eliminar
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => toggleTaskStatus(task.id)}>
                      Reabrir
                    </Button>
                  </CardFooter>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

