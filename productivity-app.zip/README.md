# Aplicación de Productividad

Esta aplicación te ayuda a mejorar tu productividad diaria con herramientas como:

- Corrector ortográfico en español
- Limpiador de texto
- Gestor de tareas

## Uso

1. Simplemente abre el archivo `index.html` en tu navegador web favorito
2. No requiere instalación ni dependencias externas
3. Funciona completamente en el navegador

## Características

### Corrector Ortográfico
- Utiliza un diccionario en español para detectar errores ortográficos
- Ofrece sugerencias para palabras mal escritas
- Permite corregir palabras individualmente o todo el texto
- Botón para copiar el texto corregido

### Limpiador de Texto
- Elimina saltos de línea innecesarios
- Corrige espacios múltiples
- Normaliza la puntuación
- Botón para copiar el texto limpio

### Gestor de Tareas
- Organiza tareas por prioridad (alta, media, baja)
- Marca tareas como completadas
- Añade imágenes a las tareas
- Filtra tareas por mes y prioridad
- Exporta e importa tareas en formato JSON
- Guardado automático cada 15 segundos

## Guardado de Datos

La aplicación guarda automáticamente tus tareas:
- En el navegador mediante localStorage
- Cada 15 segundos se realiza un guardado automático
- Puedes usar el botón "Guardar Todo" en el menú lateral para forzar un guardado
- Exporta tus tareas a un archivo JSON para hacer copias de seguridad

## Compatibilidad

Esta aplicación funciona en cualquier navegador moderno:
- Google Chrome
- Mozilla Firefox
- Microsoft Edge
- Safari
- Opera

## Uso sin conexión

Puedes usar esta aplicación sin conexión a internet. Simplemente guarda los archivos en tu computadora y abre index.html cuando lo necesites.

## Mantener tus tareas existentes

Si ya tienes tareas creadas en la versión anterior y quieres mantenerlas al actualizar:

1. En tu versión actual, haz clic en "Exportar Tareas" para guardar un archivo JSON con tus tareas
2. Descarga y abre esta nueva versión de la aplicación
3. Haz clic en "Importar Tareas" y selecciona el archivo JSON que exportaste
4. Tus tareas se cargarán en la nueva versión manteniendo todos sus datos

Este proceso te permite actualizar la aplicación sin perder ninguna de tus tareas existentes.

