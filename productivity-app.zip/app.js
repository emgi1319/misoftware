// Variables globales
let tasks = []
let lastSaved = null
let editingTaskId = null
let selectedImage = null
let autoSaveInterval = null
let spellChecker = null

// Elementos DOM
const sections = document.querySelectorAll(".section")
const navLinks = document.querySelectorAll(".nav-link")
const quickAccessButtons = document.querySelectorAll(".quick-access")

// Inicialización
document.addEventListener("DOMContentLoaded", () => {
  // Cargar tareas
  loadTasks()

  // Configurar navegación
  setupNavigation()

  // Cargar diccionario español
  loadSpellChecker()

  // Configurar corrector ortográfico
  setupCorrector()

  // Configurar limpiador de texto
  setupLimpiador()

  // Configurar gestor de tareas
  setupTaskManager()

  // Configurar guardado automático
  setupAutoSave()

  // Actualizar contadores
  updateCounters()
})

// Navegación
function setupNavigation() {
  // Navegación principal
  navLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault()
      const targetSection = link.getAttribute("data-section")
      showSection(targetSection)

      // Actualizar clase activa
      navLinks.forEach((l) => l.classList.remove("active"))
      link.classList.add("active")
    })
  })

  // Botones de acceso rápido
  quickAccessButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const targetSection = button.getAttribute("data-section")
      showSection(targetSection)

      // Actualizar clase activa en navegación
      navLinks.forEach((link) => {
        if (link.getAttribute("data-section") === targetSection) {
          link.classList.add("active")
        } else {
          link.classList.remove("active")
        }
      })
    })
  })

  // Botón de guardar todo
  document.getElementById("save-all-btn").addEventListener("click", () => {
    saveTasks()
    showNotification("Todos los datos han sido guardados")
  })
}

// Mostrar sección
function showSection(sectionId) {
  sections.forEach((section) => {
    if (section.id === sectionId) {
      section.classList.remove("hidden")
      section.classList.add("active")
    } else {
      section.classList.add("hidden")
      section.classList.remove("active")
    }
  })
}

// Cargar corrector ortográfico
function loadSpellChecker() {
  const dictionaryLoading = document.getElementById("dictionary-loading")

  // Verificar si window.nspell y window.dictionaryEs están disponibles
  if (typeof window.nspell === "undefined" || typeof window.dictionaryEs === "undefined") {
    console.error("Error: nspell o dictionary-es no están disponibles")
    dictionaryLoading.innerHTML =
      '<span class="text-red-500">Error al cargar el diccionario. Intente recargar la página.</span>'
    return
  }

  // Cargar el diccionario español
  window.dictionaryEs((err, dict) => {
    if (err) {
      console.error("Error al cargar el diccionario español:", err)
      dictionaryLoading.innerHTML =
        '<span class="text-red-500">Error al cargar el diccionario. Intente recargar la página.</span>'
      return
    }

    // Crear el corrector ortográfico
    spellChecker = window.nspell(dict)

    // Ocultar el mensaje de carga
    dictionaryLoading.classList.add("hidden")

    console.log("Diccionario español cargado correctamente")
  })
}

// Corrector ortográfico
function setupCorrector() {
  const correctorBtn = document.getElementById("corrector-btn")
  const correctorCheckBtn = document.getElementById("corrector-check-btn")
  const correctorInput = document.getElementById("corrector-input")
  const correctorOutput = document.getElementById("corrector-output")
  const correctorResult = document.getElementById("corrector-result")
  const correctorCopy = document.getElementById("corrector-copy")
  const spellCheckResult = document.getElementById("spell-check-result")
  const spellCheckOutput = document.getElementById("spell-check-output")

  // Botón de corrección automática
  correctorBtn.addEventListener("click", () => {
    const text = correctorInput.value
    if (!text.trim()) return

    if (spellChecker) {
      const correctedText = correctTextWithSpellChecker(text)
      correctorOutput.textContent = correctedText
      correctorResult.classList.remove("hidden")
      spellCheckResult.classList.add("hidden")
    } else {
      // Si el corrector no está disponible, mostrar un mensaje
      correctorOutput.textContent =
        "El corrector ortográfico no está disponible. Por favor, espere a que se cargue el diccionario o recargue la página."
      correctorResult.classList.remove("hidden")
      spellCheckResult.classList.add("hidden")
    }
  })

  // Botón de revisión ortográfica
  correctorCheckBtn.addEventListener("click", () => {
    const text = correctorInput.value
    if (!text.trim()) return

    if (spellChecker) {
      const misspelledWords = findMisspelledWords(text)

      if (misspelledWords.length > 0) {
        // Mostrar palabras con posibles errores
        const htmlOutput = highlightMisspelledWords(text, misspelledWords)
        spellCheckOutput.innerHTML = htmlOutput
        spellCheckResult.classList.remove("hidden")
        correctorResult.classList.add("hidden")
      } else {
        spellCheckOutput.innerHTML = '<p class="text-green-500">No se encontraron errores ortográficos.</p>'
        spellCheckResult.classList.remove("hidden")
        correctorResult.classList.add("hidden")
      }
    } else {
      // Si el corrector no está disponible, mostrar un mensaje
      spellCheckOutput.innerHTML =
        '<p class="text-red-500">El corrector ortográfico no está disponible. Por favor, espere a que se cargue el diccionario o recargue la página.</p>'
      spellCheckResult.classList.remove("hidden")
      correctorResult.classList.add("hidden")
    }
  })

  // Copiar texto corregido
  correctorCopy.addEventListener("click", () => {
    const text = correctorOutput.textContent
    copyToClipboard(text, correctorCopy)
  })

  // Manejar clics en palabras mal escritas
  spellCheckOutput.addEventListener("click", (e) => {
    if (e.target.classList.contains("misspelled")) {
      showSuggestions(e.target)
    }
  })

  // Cerrar sugerencias al hacer clic fuera
  document.addEventListener("click", (e) => {
    if (!e.target.classList.contains("misspelled") && !e.target.closest(".suggestion-list")) {
      const suggestionLists = document.querySelectorAll(".suggestion-list")
      suggestionLists.forEach((list) => list.remove())
    }
  })
}

// Función para corregir texto con el corrector ortográfico
function correctTextWithSpellChecker(text) {
  if (!spellChecker) return text

  // Dividir el texto en palabras y espacios
  const tokens = text.split(/(\s+)/)

  // Corregir cada palabra
  const correctedTokens = tokens.map((token) => {
    // Si es un espacio, devolverlo tal cual
    if (/\s+/.test(token)) return token

    // Ignorar palabras que contienen números o símbolos
    if (!/^[a-záéíóúüñ]+$/i.test(token)) return token

    // Verificar si la palabra está bien escrita
    if (!spellChecker.correct(token)) {
      // Obtener sugerencias
      const suggestions = spellChecker.suggest(token)

      // Si hay sugerencias, usar la primera
      if (suggestions && suggestions.length > 0) {
        return suggestions[0]
      }
    }

    return token
  })

  // Unir las palabras corregidas
  let correctedText = correctedTokens.join("")

  // Corregir signos de puntuación
  correctedText = correctedText.replace(/([.!?])([A-Za-zÁÉÍÓÚáéíóúÑñ])/g, "$1 $2").replace(/,([^ ])/g, ", $1")

  return correctedText
}

// Función para encontrar palabras mal escritas
function findMisspelledWords(text) {
  if (!spellChecker) return []

  // Dividir el texto en palabras
  const words = text.match(/[a-záéíóúüñ]+/gi) || []
  const misspelledWords = []

  words.forEach((word) => {
    // Ignorar palabras cortas (menos de 3 letras)
    if (word.length < 3) return

    // Verificar si la palabra está bien escrita
    if (!spellChecker.correct(word)) {
      misspelledWords.push(word)
    }
  })

  // Eliminar duplicados
  return [...new Set(misspelledWords)]
}

// Función para resaltar palabras mal escritas
function highlightMisspelledWords(text, misspelledWords) {
  let htmlText = text

  // Reemplazar cada palabra mal escrita con una versión resaltada
  misspelledWords.forEach((word) => {
    const regex = new RegExp(`\\b${word}\\b`, "gi")
    htmlText = htmlText.replace(regex, `<span class="misspelled" data-word="${word}">${word}</span>`)
  })

  // Convertir saltos de línea en <br>
  htmlText = htmlText.replace(/\n/g, "<br>")

  return `
    <div class="mb-4">
      <p class="text-sm text-gray-600 mb-2">Haz clic en las palabras subrayadas para ver sugerencias:</p>
      <div class="p-3 bg-gray-50 rounded border">${htmlText}</div>
    </div>
    <div>
      <p class="text-sm text-gray-600">Palabras con posibles errores (${misspelledWords.length}):</p>
      <ul class="list-disc pl-5 mt-2">
        ${misspelledWords
          .slice(0, 10)
          .map((word) => {
            const suggestions = spellChecker.suggest(word).slice(0, 3)
            return `<li class="text-sm"><span class="font-medium">${word}</span> → <span class="text-green-600">${suggestions.join(", ")}</span></li>`
          })
          .join("")}
        ${misspelledWords.length > 10 ? `<li class="text-sm text-gray-500">Y ${misspelledWords.length - 10} más...</li>` : ""}
      </ul>
    </div>
  `
}

// Función para mostrar sugerencias
function showSuggestions(wordElement) {
  // Eliminar listas de sugerencias existentes
  const existingLists = document.querySelectorAll(".suggestion-list")
  existingLists.forEach((list) => list.remove())

  const word = wordElement.getAttribute("data-word")

  // Obtener sugerencias del corrector
  const suggestions = spellChecker.suggest(word)

  if (!suggestions || suggestions.length === 0) return

  // Crear lista de sugerencias
  const suggestionList = document.createElement("div")
  suggestionList.className = "suggestion-list"

  // Añadir cada sugerencia a la lista
  suggestions.slice(0, 5).forEach((suggestion) => {
    const item = document.createElement("div")
    item.className = "suggestion-item"
    item.textContent = suggestion

    // Al hacer clic en una sugerencia, reemplazar la palabra
    item.addEventListener("click", () => {
      wordElement.textContent = suggestion
      wordElement.classList.remove("misspelled")
      suggestionList.remove()
    })

    suggestionList.appendChild(item)
  })

  // Posicionar la lista debajo de la palabra
  const rect = wordElement.getBoundingClientRect()
  suggestionList.style.top = `${rect.bottom + window.scrollY}px`
  suggestionList.style.left = `${rect.left + window.scrollX}px`

  // Añadir la lista al documento
  document.body.appendChild(suggestionList)
}

// Limpiador de texto
function setupLimpiador() {
  const limpiadorBtn = document.getElementById("limpiador-btn")
  const limpiadorInput = document.getElementById("limpiador-input")
  const limpiadorOutput = document.getElementById("limpiador-output")
  const limpiadorResult = document.getElementById("limpiador-result")
  const limpiadorCopy = document.getElementById("limpiador-copy")

  limpiadorBtn.addEventListener("click", () => {
    const text = limpiadorInput.value
    if (!text.trim()) return

    const cleanedText = cleanText(text)
    limpiadorOutput.textContent = cleanedText
    limpiadorResult.classList.remove("hidden")
  })

  limpiadorCopy.addEventListener("click", () => {
    const text = limpiadorOutput.textContent
    copyToClipboard(text, limpiadorCopy)
  })
}

// Función para limpiar texto
function cleanText(text) {
  // Eliminar saltos de línea múltiples
  let cleaned = text.replace(/\n+/g, " ")

  // Eliminar espacios múltiples
  cleaned = cleaned.replace(/\s+/g, " ")

  // Eliminar espacios antes de puntuación
  cleaned = cleaned.replace(/\s+([.,;:!?])/g, "$1")

  // Asegurar un espacio después de la puntuación
  cleaned = cleaned.replace(/([.,;:!?])([^\s])/g, "$1 $2")

  // Eliminar espacios al inicio y final
  cleaned = cleaned.trim()

  return cleaned
}

// Gestor de tareas
function setupTaskManager() {
  // Botones principales
  const newTaskBtn = document.getElementById("new-task-btn")
  const exportTasksBtn = document.getElementById("export-tasks")
  const importTasksInput = document.getElementById("import-tasks")

  // Modal
  const taskModal = document.getElementById("task-modal")
  const modalTitle = document.getElementById("modal-title")
  const taskForm = document.getElementById("task-form")
  const taskIdInput = document.getElementById("task-id")
  const taskTitleInput = document.getElementById("task-title")
  const taskDescriptionInput = document.getElementById("task-description")
  const taskPriorityInput = document.getElementById("task-priority")
  const taskImageInput = document.getElementById("task-image")
  const imageUploadBtn = document.getElementById("image-upload-btn")
  const imagePreview = document.getElementById("image-preview")
  const previewImg = document.getElementById("preview-img")
  const imageSelected = document.getElementById("image-selected")
  const imageBtnText = document.getElementById("image-btn-text")
  const cancelTaskBtn = document.getElementById("cancel-task")
  const saveTaskBtn = document.getElementById("save-task")
  const saveBtnText = document.getElementById("save-btn-text")

  // Filtros
  const filterPriority = document.getElementById("filter-priority")
  const filterMonth = document.getElementById("filter-month")

  // Contenedores de tareas
  const pendingTasksContainer = document.getElementById("pending-tasks-container")
  const completedTasksContainer = document.getElementById("completed-tasks-container")

  // Abrir modal para nueva tarea
  newTaskBtn.addEventListener("click", () => {
    resetTaskForm()
    modalTitle.textContent = "Agregar Nueva Tarea"
    saveBtnText.textContent = "Guardar"
    taskModal.classList.remove("hidden")
  })

  // Cerrar modal
  cancelTaskBtn.addEventListener("click", () => {
    taskModal.classList.add("hidden")
    resetTaskForm()
  })

  // Subir imagen
  imageUploadBtn.addEventListener("click", () => {
    taskImageInput.click()
  })

  // Manejar selección de imagen
  taskImageInput.addEventListener("change", (e) => {
    const file = e.target.files[0]
    if (file) {
      selectedImage = file
      const reader = new FileReader()
      reader.onload = (e) => {
        previewImg.src = e.target.result
        imagePreview.classList.remove("hidden")
        imageSelected.classList.remove("hidden")
        imageBtnText.textContent = "Cambiar imagen"
      }
      reader.readAsDataURL(file)
    }
  })

  // Guardar tarea
  saveTaskBtn.addEventListener("click", () => {
    const title = taskTitleInput.value.trim()
    if (!title) return

    if (editingTaskId) {
      // Actualizar tarea existente
      updateTask(editingTaskId)
    } else {
      // Crear nueva tarea
      createTask()
    }

    taskModal.classList.add("hidden")
    resetTaskForm()
    renderTasks()
    saveTasks()
  })

  // Exportar tareas
  exportTasksBtn.addEventListener("click", () => {
    const tasksJson = JSON.stringify(tasks, null, 2)
    const blob = new Blob([tasksJson], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "mis-tareas.json"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  })

  // Importar tareas
  importTasksInput.addEventListener("change", (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const importedTasks = JSON.parse(e.target.result)
          tasks = importedTasks.map((task) => ({
            ...task,
            createdAt: new Date(task.createdAt),
          }))
          renderTasks()
          saveTasks()
          updateCounters()
        } catch (error) {
          console.error("Error importing tasks:", error)
          alert("Error al importar tareas. Asegúrate de que el archivo tenga el formato correcto.")
        }
      }
      reader.readAsText(file)
    }
  })

  // Filtros
  filterPriority.addEventListener("change", renderTasks)
  filterMonth.addEventListener("change", renderTasks)
}

// Crear nueva tarea
function createTask() {
  const title = document.getElementById("task-title").value.trim()
  const description = document.getElementById("task-description").value.trim()
  const priority = document.getElementById("task-priority").value
  let imageUrl = ""

  if (selectedImage) {
    const reader = new FileReader()
    reader.onload = (e) => {
      imageUrl = e.target.result

      const task = {
        id: Date.now().toString(),
        title,
        description,
        priority,
        status: "pendiente",
        createdAt: new Date(),
        imageUrl,
      }

      tasks.push(task)
      renderTasks()
      saveTasks()
      updateCounters()
    }
    reader.readAsDataURL(selectedImage)
  } else {
    const task = {
      id: Date.now().toString(),
      title,
      description,
      priority,
      status: "pendiente",
      createdAt: new Date(),
      imageUrl,
    }

    tasks.push(task)
    renderTasks()
    saveTasks()
    updateCounters()
  }
}

// Actualizar tarea existente
function updateTask(id) {
  const title = document.getElementById("task-title").value.trim()
  const description = document.getElementById("task-description").value.trim()
  const priority = document.getElementById("task-priority").value

  const taskIndex = tasks.findIndex((task) => task.id === id)
  if (taskIndex === -1) return

  const updatedTask = {
    ...tasks[taskIndex],
    title,
    description,
    priority,
  }

  if (selectedImage) {
    const reader = new FileReader()
    reader.onload = (e) => {
      updatedTask.imageUrl = e.target.result
      tasks[taskIndex] = updatedTask
      renderTasks()
      saveTasks()
    }
    reader.readAsDataURL(selectedImage)
  } else {
    tasks[taskIndex] = updatedTask
    renderTasks()
    saveTasks()
  }
}

// Cambiar estado de tarea
function toggleTaskStatus(id) {
  const taskIndex = tasks.findIndex((task) => task.id === id)
  if (taskIndex === -1) return

  tasks[taskIndex].status = tasks[taskIndex].status === "pendiente" ? "completada" : "pendiente"
  renderTasks()
  saveTasks()
  updateCounters()
}

// Eliminar tarea
function deleteTask(id) {
  if (confirm("¿Estás seguro de que deseas eliminar esta tarea?")) {
    tasks = tasks.filter((task) => task.id !== id)
    renderTasks()
    saveTasks()
    updateCounters()
  }
}

// Editar tarea
function editTask(id) {
  const task = tasks.find((task) => task.id === id)
  if (!task) return

  editingTaskId = id
  document.getElementById("task-id").value = id
  document.getElementById("task-title").value = task.title
  document.getElementById("task-description").value = task.description
  document.getElementById("task-priority").value = task.priority

  if (task.imageUrl) {
    document.getElementById("preview-img").src = task.imageUrl
    document.getElementById("image-preview").classList.remove("hidden")
    document.getElementById("image-selected").classList.remove("hidden")
    document.getElementById("image-btn-text").textContent = "Cambiar imagen"
  }

  document.getElementById("modal-title").textContent = "Editar Tarea"
  document.getElementById("save-btn-text").textContent = "Actualizar"
  document.getElementById("task-modal").classList.remove("hidden")
}

// Resetear formulario
function resetTaskForm() {
  document.getElementById("task-form").reset()
  document.getElementById("task-id").value = ""
  document.getElementById("image-preview").classList.add("hidden")
  document.getElementById("image-selected").classList.add("hidden")
  document.getElementById("image-btn-text").textContent = "Subir imagen"
  editingTaskId = null
  selectedImage = null
}

// Renderizar tareas
function renderTasks() {
  const pendingContainer = document.getElementById("pending-tasks-container")
  const completedContainer = document.getElementById("completed-tasks-container")
  const priorityFilter = document.getElementById("filter-priority").value
  const monthFilter = document.getElementById("filter-month").value

  // Filtrar tareas
  const filteredTasks = tasks.filter((task) => {
    // Filtrar por prioridad
    if (priorityFilter !== "todas" && task.priority !== priorityFilter) {
      return false
    }

    // Filtrar por mes
    if (monthFilter !== "todos") {
      const taskMonth = new Date(task.createdAt).getMonth().toString()
      if (taskMonth !== monthFilter) {
        return false
      }
    }

    return true
  })

  // Separar por estado
  const pendingTasks = filteredTasks.filter((task) => task.status === "pendiente")
  const completedTasks = filteredTasks.filter((task) => task.status === "completada")

  // Actualizar contadores
  document.getElementById("pending-tasks-count").textContent = pendingTasks.length
  document.getElementById("completed-tasks-count").textContent = completedTasks.length

  // Renderizar tareas pendientes
  if (pendingTasks.length === 0) {
    pendingContainer.innerHTML = `
      <div class="bg-white rounded-lg border shadow-sm p-4 text-gray-500 text-center">
        No hay tareas pendientes
      </div>
    `
  } else {
    pendingContainer.innerHTML = pendingTasks.map((task) => createTaskCard(task)).join("")
  }

  // Renderizar tareas completadas
  if (completedTasks.length === 0) {
    completedContainer.innerHTML = `
      <div class="bg-white rounded-lg border shadow-sm p-4 text-gray-500 text-center">
        No hay tareas completadas
      </div>
    `
  } else {
    completedContainer.innerHTML = completedTasks.map((task) => createTaskCard(task)).join("")
  }

  // Añadir event listeners a los botones
  document.querySelectorAll(".toggle-status-btn").forEach((btn) => {
    btn.addEventListener("click", () => toggleTaskStatus(btn.getAttribute("data-id")))
  })

  document.querySelectorAll(".edit-task-btn").forEach((btn) => {
    btn.addEventListener("click", () => editTask(btn.getAttribute("data-id")))
  })

  document.querySelectorAll(".delete-task-btn").forEach((btn) => {
    btn.addEventListener("click", () => deleteTask(btn.getAttribute("data-id")))
  })
}

// Crear tarjeta de tarea
function createTaskCard(task) {
  const isCompleted = task.status === "completada"
  const priorityClass = `priority-${task.priority}`
  const priorityLabel = task.priority === "alta" ? "Urgente" : task.priority === "media" ? "Intermedio" : "Bajo"
  const priorityIcon =
    task.priority === "alta" ? "exclamation-circle" : task.priority === "media" ? "exclamation-triangle" : "clock"
  const date = new Date(task.createdAt).toLocaleDateString()

  return `
    <div class="bg-white rounded-lg border shadow-sm overflow-hidden task-card ${isCompleted ? "completed-task" : ""} fade-in">
      <div class="p-4 border-b">
        <div class="flex justify-between items-center">
          <h3 class="text-lg font-medium task-title">${task.title}</h3>
          <span class="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full border ${priorityClass}">
            <i class="fas fa-${priorityIcon}"></i> ${priorityLabel}
          </span>
        </div>
        <div class="text-xs text-gray-500 flex items-center gap-1 mt-1">
          <i class="fas fa-calendar"></i> ${date}
        </div>
      </div>
      <div class="p-4">
        <p class="text-sm">${task.description}</p>
        ${
          task.imageUrl
            ? `
          <div class="mt-2">
            <img src="${task.imageUrl}" alt="${task.title}" class="max-h-40 rounded object-contain">
          </div>
        `
            : ""
        }
      </div>
      <div class="p-4 border-t flex justify-between">
        <div class="flex gap-2">
          ${
            !isCompleted
              ? `
            <button class="border rounded px-2 py-1 text-sm hover:bg-gray-100 edit-task-btn" data-id="${task.id}">
              <i class="fas fa-edit mr-1"></i> Editar
            </button>
          `
              : ""
          }
          <button class="border rounded px-2 py-1 text-sm hover:bg-gray-100 delete-task-btn" data-id="${task.id}">
            <i class="fas fa-trash mr-1"></i> Eliminar
          </button>
        </div>
        <button class="border rounded px-2 py-1 text-sm hover:bg-gray-100 toggle-status-btn" data-id="${task.id}">
          ${isCompleted ? "Reabrir" : '<i class="fas fa-check-circle mr-1"></i> Completar'}
        </button>
      </div>
    </div>
  `
}

// Cargar tareas
function loadTasks() {
  const savedTasks = localStorage.getItem("tasks")
  if (savedTasks) {
    try {
      tasks = JSON.parse(savedTasks).map((task) => ({
        ...task,
        createdAt: new Date(task.createdAt),
      }))
      renderTasks()
      updateLastSaved()
    } catch (error) {
      console.error("Error loading tasks:", error)
      tasks = []
    }
  }
}

// Guardar tareas
function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks))
  updateLastSaved()
  updateCounters()
}

// Configurar guardado automático
function setupAutoSave() {
  // Guardar cada 15 segundos
  autoSaveInterval = setInterval(() => {
    if (tasks.length > 0) {
      saveTasks()
      console.log("Auto-save executed")
    }
  }, 15000)
}

// Actualizar última vez guardado
function updateLastSaved() {
  lastSaved = new Date()
  const lastSavedElement = document.getElementById("last-saved")
  if (lastSavedElement) {
    lastSavedElement.textContent = `Último guardado: ${lastSaved.toLocaleTimeString()}`
  }
}

// Actualizar contadores
function updateCounters() {
  const pendingCount = tasks.filter((task) => task.status === "pendiente").length
  const completedCount = tasks.filter((task) => task.status === "completada").length

  document.getElementById("pending-count").textContent = pendingCount
  document.getElementById("completed-count").textContent = completedCount
}

// Copiar al portapapeles
function copyToClipboard(text, button) {
  navigator.clipboard
    .writeText(text)
    .then(() => {
      const originalHTML = button.innerHTML
      button.innerHTML = '<i class="fas fa-check"></i> Copiado'

      setTimeout(() => {
        button.innerHTML = originalHTML
      }, 2000)
    })
    .catch((err) => {
      console.error("Error copying text: ", err)
    })
}

// Mostrar notificación
function showNotification(message) {
  const notification = document.createElement("div")
  notification.className = "save-notification"
  notification.innerHTML = `<i class="fas fa-check-circle mr-2"></i> ${message}`
  document.body.appendChild(notification)

  setTimeout(() => {
    notification.remove()
  }, 3000)
}

