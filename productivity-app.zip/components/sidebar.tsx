"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Type, FileText, CheckSquare, Settings, Save } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { useEffect } from "react"

export function Sidebar() {
  const pathname = usePathname()

  const navItems = [
    { href: "/", label: "Inicio", icon: Home },
    { href: "/corrector", label: "Corrector", icon: Type },
    { href: "/limpiador", label: "Limpiador", icon: FileText },
    { href: "/tareas", label: "Tareas", icon: CheckSquare },
    { href: "/configuracion", label: "Configuración", icon: Settings },
  ]

  // Función para guardar todos los datos
  const saveAllData = () => {
    // Guardar datos en localStorage
    const tasks = localStorage.getItem("tasks")
    if (tasks) {
      try {
        // También podríamos guardar en el sistema de archivos a través de la API
        fetch("/api/db", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: tasks,
        })
          .then((response) => response.json())
          .then((data) => {
            console.log("Datos guardados correctamente:", data)
            // Mostrar notificación o feedback al usuario
            alert("Datos guardados correctamente")
          })
          .catch((error) => {
            console.error("Error al guardar datos:", error)
          })
      } catch (error) {
        console.error("Error al procesar datos:", error)
      }
    }
  }

  // Configurar guardado automático cada 30 segundos
  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      console.log("Guardado automático ejecutado")
      saveAllData()
    }, 30000) // 30 segundos

    return () => clearInterval(autoSaveInterval)
  }, [])

  return (
    <div className="flex h-screen w-64 flex-col border-r bg-background">
      <div className="flex h-14 items-center border-b px-4">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <span className="text-xl font-bold">Productividad</span>
        </Link>
      </div>
      <div className="flex-1 overflow-auto py-4">
        <nav className="grid gap-2 px-4">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-accent",
                  isActive ? "bg-accent text-accent-foreground" : "text-muted-foreground",
                )}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* Botón de guardado */}
        <div className="mt-6 px-4">
          <Button onClick={saveAllData} className="w-full flex items-center justify-center gap-2" variant="outline">
            <Save className="h-4 w-4" />
            Guardar Todo
          </Button>
        </div>
      </div>
      <div className="mt-auto border-t p-4">
        <div className="flex items-center gap-3 rounded-lg px-3 py-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
            U
          </div>
          <div>
            <p className="text-sm font-medium">Usuario</p>
            <p className="text-xs text-muted-foreground">usuario@ejemplo.com</p>
          </div>
        </div>
      </div>
    </div>
  )
}

